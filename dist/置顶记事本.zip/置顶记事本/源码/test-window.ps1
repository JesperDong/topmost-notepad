$ErrorActionPreference = 'Stop'
$compilerPath = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$frameworkDirectory = Split-Path -Parent $compilerPath
$targetPath = Join-Path $PSScriptRoot 'TestWindow.exe'
$arguments = @('/nologo','/target:exe','/codepage:65001', "/out:$targetPath",
    "/reference:$(Join-Path $frameworkDirectory 'WPF\PresentationFramework.dll')",
    "/reference:$(Join-Path $frameworkDirectory 'WPF\PresentationCore.dll')",
    "/reference:$(Join-Path $frameworkDirectory 'WPF\WindowsBase.dll')",'/reference:System.Xaml.dll',
    "/reference:$(Join-Path $PSScriptRoot 'lib\ICSharpCode.AvalonEdit.dll')",
    "/resource:$(Join-Path $PSScriptRoot 'MainWindow.xaml'),TopNote.MainWindow.xaml",
    "/resource:$(Join-Path $PSScriptRoot 'app.ico'),TopNote.app.ico",
    (Join-Path $PSScriptRoot 'Document.cs'), (Join-Path $PSScriptRoot 'Dialogs.cs'),
    (Join-Path $PSScriptRoot 'KnowledgeRegions.cs'),
    (Join-Path $PSScriptRoot 'MainWindow.cs'), (Join-Path $PSScriptRoot 'TestWindow.cs'))
& $compilerPath @arguments
if ($LASTEXITCODE -ne 0) { throw '测试编译失败' }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'app.config') -Destination "$targetPath.config" -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'lib\ICSharpCode.AvalonEdit.dll') -Destination $PSScriptRoot -Force
& $targetPath
if ($LASTEXITCODE -ne 0) { throw '窗口测试失败' }
